FARM CAPITALIST: PRESS KIT

Game: Farm Capitalist (Google Play title: Farm Capitalist: Idle Tycoon)
Developer: Causality
Platform: Android 7.0 or newer
Release: Coming soon to Google Play
Genre: Idle tycoon, farming, 16-bit pixel art
Price: Free to play. Optional rewarded video ads. Optional purchases: gem packs, a one-time Starter Pack and the VIP Farm Club monthly subscription.
Languages: English, Japanese
Account: None needed. Cloud save with a Google account is optional.
Website: https://causalityviolation.github.io/FarmCap/
Privacy policy: https://causalityviolation.github.io/FarmCapPrivacy/
Press contact: dev.causality@gmail.com

SHORT DESCRIPTION
Grow crops, hire Farm Hands and ship the harvest in a cozy pixel-art idle game.

ABOUT
Farm Capitalist is a cozy idle tycoon game with 16-bit pixel art, made for Android. You start with a single turnip and grow it into a sprawling farm: tap to harvest, buy more crops and hire Farm Hands who keep working even while the game is closed.

When progress slows down, you ship the harvest to the city and start the season again with Golden Seeds that make every future harvest worth more. The farm turns to a starry night after dark, every season has its own song, and the Wardrobe lets you dress up the farm with hats, outfits, pets and decorations.

The game is free to play, with optional rewarded ads and optional purchases. It needs no account and comes in English and Japanese.

FEATURES
- 18 crops, animals and facilities, from turnips and carrots to dairy cows, truffle pigs and comet fruit, then a farm shop, a cannery and robot harvesters.
- Farm Hands harvest while the game is closed, for up to 12 hours (more with barn upgrades).
- Ship the harvest each season for Golden Seeds that boost every future harvest, and spend the Research Points they bring on a skill tree.
- A song for every season, all synthesized in code, and a starry night sky that follows the phone’s clock.
- The Wardrobe: hats, outfits, pets, garden gnomes and a hot-air balloon. They only change how the farm looks.
- Daily and weekly missions, 50+ achievements, a 7-day gift streak, limited-time events and an optional weekly Top Farmers leaderboard.
- Free and fair: ads are always optional, and gems save time but never decide a race.

VIDEOS AND STREAMS
You are welcome to record, stream and monetise videos of Farm Capitalist; there is no need to ask. If you would like anything for your video, such as the trailer file or a different screenshot size, just write to us.

FILES
logo.png                       transparent background
icon-512.png                   app icon, 512 x 512
feature-graphic-1024x500.png    the Google Play banner
screenshots/en                 phone screenshots, 1080 x 2160, no captions
screenshots/en-captioned       the same with the store captions
screenshots/ja, ja-captioned   the Japanese game, without and with captions
